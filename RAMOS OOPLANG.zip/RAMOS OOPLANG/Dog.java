import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Dog extends JFrame
{
    String breed= "Bulldog";
    String tagnumber= "666" ;
    String color = "Black";
    
    JTextField b1 = new JTextField();
    JTextField b2 = new JTextField();
    JTextField b3 =  new JTextField();
    
    JLabel l1 = new JLabel();
    JLabel l2 = new JLabel();
    JLabel l3 = new JLabel();
    JButton ResultButton = new JButton();
    JButton exitButton = new JButton();
    public Dog (){
        setTitle("Dog Bred");
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();  
            
        exitButton.setText("EXIT");
        gridConstraints.gridx=2;
        gridConstraints.gridy=7;
        getContentPane().add(exitButton,gridConstraints);
        
        exitButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                exitButtonActionPerformed(e);
            }
        });
        
        l1.setText("Breed :");
        gridConstraints.gridx=0;
        gridConstraints.gridy=1;
        getContentPane().add(l1,gridConstraints);
        
        l2.setText("Tag No. :");
        gridConstraints.gridx=0;
        gridConstraints.gridy=3;
        getContentPane().add(l2,gridConstraints);
        
        l3.setText("Color :");
        gridConstraints.gridx=0;
        gridConstraints.gridy=5;
        getContentPane().add(l3,gridConstraints);
        
        ResultButton.setText("Result");
        gridConstraints.gridx=0;
        gridConstraints.gridy=7;
        getContentPane().add(ResultButton,gridConstraints);
    
        ResultButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                ResultButtonActionPerformed(e);
            }
        });
        
        b1.setText("Enter Breed");
        b1.setColumns(15);
        gridConstraints.gridx=2;
        gridConstraints.gridy=1 ;
        getContentPane().add(b1,gridConstraints);
        
        b2.setText("Enter Tag No.");
        b2.setColumns(15);
        gridConstraints.gridx=2;
        gridConstraints.gridy=3 ;
        getContentPane().add(b2,gridConstraints);
        
        b3.setText("Enter Color");
        b3.setColumns(15);
        gridConstraints.gridx=2;
        gridConstraints.gridy=5 ;
        getContentPane().add(b3,gridConstraints);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600,600);
        
    }
    private void exitButtonActionPerformed(ActionEvent e)
    {
        JFrame f;
        f=new JFrame();
        JOptionPane.showMessageDialog(f,"Thank You For Using The Program! Made By: David Andre Ramos","Thank You",JOptionPane.PLAIN_MESSAGE);
        System.exit(0);
    }
    private void ResultButtonActionPerformed(ActionEvent e)
    {
        JFrame f;
        f=new JFrame();
        String Breedlol= b1.getText();
        String Taglol= b2.getText();
        String Colorlol= b3.getText();
        JOptionPane.showMessageDialog(f,"Dog Breed : " +Breedlol + ", Tag No is : "+ Taglol + ", Color: " + Colorlol ,"Thank You",JOptionPane.PLAIN_MESSAGE);
        
        System.exit(0);
    }
    public void Dog2 (String breed, String tagnumber, String color){
         String b= "Bulldog";
         String t= "666" ;
         String c = "Black";
         System.out.println("Dog Breed : " +breed + ", Tag No is : "+ tagnumber + ", Color: " + color );
        }
    public void  printInfo(){
        System.out.println("Dog Breed : " +breed + ", Tag No is : "+ tagnumber + ", Color: " + color );
    
        }
    public static void main (String [] args){
        
        Dog mydog = new Dog();
        mydog.printInfo();
        mydog.Dog2("Bulldog","666","Black");
        new Dog().show();
    }
}