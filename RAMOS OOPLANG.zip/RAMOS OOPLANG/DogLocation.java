public class DogLocation{
    String location; 
    public static getter(
}