import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.math.RoundingMode;
import java.text.DecimalFormat;
public class Test123 extends JFrame{
    JButton okButton = new JButton();
    JButton exitButton = new JButton();
    JButton calculateButton = new JButton();
    JButton clearButton = new JButton();

    JLabel WeightLabel = new JLabel();
    JLabel HeightLabel = new JLabel();
    JLabel ResultLabel = new JLabel();
    JLabel InchesLabel = new JLabel();
    JLabel PoundsLabel = new JLabel();

    JTextField WeightTextField = new JTextField();
    JTextField HeightTextField = new JTextField();
    JTextField ResultTextField = new JTextField();
    private static final DecimalFormat df = new DecimalFormat("0.00");
    public Test123(){
        setTitle("BMI Calculator");
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();
        
        exitButton.setText("Exit");
        gridConstraints.gridx=3;
        gridConstraints.gridy=7;
        getContentPane().add(exitButton,gridConstraints);
        
        exitButton.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
              exitButtonActionPerformed(e);
          }
        });
        
        clearButton.setText("Clear");
        gridConstraints.gridx=2;
        gridConstraints.gridy=7;
        getContentPane().add(clearButton,gridConstraints);
        
        clearButton.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
              clearButtonActionPerformed(e);
          }
        });
        
        
        HeightLabel.setText("Height :");
        gridConstraints.gridx=0;
        gridConstraints.gridy=1;
        getContentPane().add(HeightLabel,gridConstraints);
        
        InchesLabel.setText("inches");
        gridConstraints.gridx=3;
        gridConstraints.gridy=1;
        getContentPane().add(InchesLabel,gridConstraints);
        
        WeightLabel.setText("Weight :");
        gridConstraints.gridx=0;
        gridConstraints.gridy=3;
        getContentPane().add(WeightLabel,gridConstraints);
        
        PoundsLabel.setText("pounds");
        gridConstraints.gridx=3;
        gridConstraints.gridy=3;
        getContentPane().add(PoundsLabel,gridConstraints);
        
        ResultLabel.setText("Result: ");
        gridConstraints.gridx=0;
        gridConstraints.gridy=5;
        getContentPane().add(ResultLabel,gridConstraints);
        
        calculateButton.setText("Compute BMI");
        gridConstraints.gridx=0;
        gridConstraints.gridy=7;
        getContentPane().add(calculateButton,gridConstraints);
        
        calculateButton.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
              calculateButtonActionPerformed(e);
          }
        });
        
        HeightTextField.setText("");
        HeightTextField.setColumns(15);
        gridConstraints.gridx=2;
        gridConstraints.gridy=1;
        getContentPane().add(HeightTextField,gridConstraints);
        
        
        
        WeightTextField.setText("");
        WeightTextField.setColumns(15);
        gridConstraints.gridx=2;
        gridConstraints.gridy=3;
        getContentPane().add(WeightTextField,gridConstraints);
        
        ResultTextField.setText("");
        ResultTextField.setColumns(15);
        gridConstraints.gridx=2;
        gridConstraints.gridy=5;
        getContentPane().add(ResultTextField,gridConstraints);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600,600);

    }
    private void calculateButtonActionPerformed(ActionEvent e){
        JFrame f;
        f=new JFrame();
        
        double weight=Double.parseDouble(WeightTextField.getText());
        double height=Double.parseDouble(HeightTextField.getText());
        double bmi = weight / Math.pow(height, 2) * 703;
        df.setRoundingMode(RoundingMode.UP);
        if (bmi < 18.5){
            ResultTextField .setText("Underweight - BMI : "+df.format(bmi));
        }else if (bmi < 25){
            ResultTextField .setText("Normal - BMI : "+df.format(bmi));
        }else if (bmi < 30){
            ResultTextField .setText("Underweight - BMI : "+df.format(bmi));
        }else{
            ResultTextField .setText("Obese - BMI : "+df.format(bmi));
        }
        
    }
    private void clearButtonActionPerformed (ActionEvent e){
        JFrame f;
        f=new JFrame();
        HeightTextField.setText("");
        WeightTextField.setText("");
        ResultTextField.setText("");
    }
    private void exitButtonActionPerformed(ActionEvent e){
        JFrame f;
        f=new JFrame();
        JOptionPane.showMessageDialog(f,"Thank You For Using The Program! Made By: David Andre Ramos","Thank You",JOptionPane.PLAIN_MESSAGE);
        System.exit(0);
    }
    public static void main (String [] args){
        new Test123().show();
    }
    }
    



